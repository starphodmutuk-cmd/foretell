# foretell
gabling
